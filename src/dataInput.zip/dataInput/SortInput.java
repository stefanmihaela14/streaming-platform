package dataInput;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class SortInput {
    private String rating;
    private String duration;
}
